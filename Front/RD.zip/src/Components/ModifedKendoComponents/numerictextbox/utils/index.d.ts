import { NumericTextBoxState } from '../interfaces/NumericTextBoxState';
import { NumberFormatOptions } from '@progress/kendo-react-intl';
/**
 * @hidden
 */
export declare const getInitialState: () => NumericTextBoxState;
/**
 * @hidden
 */
export declare const getStateOrPropsValue: (value: number, stateValue: number) => number;
/**
 * @hidden
 */
export declare const formatValue: (value: string | number, format: string | NumberFormatOptions, intlService: any) => string;
/**
 * @hidden
 */
export declare const fractionLength: (value: number) => number;
/**
 * @hidden
 */
export declare const limitPrecision: (precision: number) => number;
/**
 * @hidden
 */
export declare const toFixedPrecision: (value: number, precision: number) => number;
/**
 * @hidden
 */
export declare const increaseValue: (value: any, newState: any, step: any, min: any, max: any, format: any, intlService: any) => void;
/**
 * @hidden
 */
export declare const decreaseValue: (value: any, newState: any, step: any, min: any, max: any, format: any, intlService: any) => void;
/**
 * @hidden
 */
export declare const rangeValue: (value: number, min: any, max: any) => number;
/**
 * @hidden
 */
export declare const getMaxCursorPosition: (nextValue: string, formatInfo: string[][]) => number;
/**
 * @hidden
 */
export declare const getMinCursorPosition: (nextValue: string, formatInfo: string[][]) => number;
/**
 * @hidden
 */
export declare const rangeSelection: (nextLooseValue: string, formatInfo: string[][], newState: NumericTextBoxState) => void;
/**
 * @hidden
 */
export declare const setSelection: (newState: NumericTextBoxState, newIndex: number, nextLooseValue: string, formatInfo: string[][]) => void;
/**
 * @hidden
 */
export declare const setInvalid: (newState: NumericTextBoxState, format: string | NumberFormatOptions, formatInfo: string[][], intlService: any) => void;
/**
 * @hidden
 */
export declare const isMinusSymbolAdded: (newState: NumericTextBoxState, symbols: any) => boolean;
/**
 * @hidden
 */
export declare const isMinusSymbolRemoved: (newState: NumericTextBoxState, symbols: any) => boolean;
/**
 * @hidden
 */
export declare const isDecimalDuplicated: (newState: NumericTextBoxState, symbols: any) => boolean;
/**
 * @hidden
 */
export declare const getFormatPrefixSufix: (format: string | NumberFormatOptions, intlService: any) => {
    positiveInfo: string[];
    negativeInfo: string[];
    zeroInfo: string[];
    oneInfo: string[];
};
/**
 * @hidden
 */
export declare const getFormatSymbols: (format: string | NumberFormatOptions, intlService: any) => string;
/**
 * @hidden
 */
export declare const getInitialPosition: (nextLooseValue: string, symbols: any) => number;
/**
 * @hidden
 */
export declare const reverseString: (str: string) => string;
/**
 * @hidden
 */
export declare const getLastNumberIndex: (currentLooseValue: string, inputRegex: RegExp) => number;
/**
 * @hidden
 */
export declare const getPrefix: (str: string) => string;
/**
 * @hidden
 */
export declare const getSuffix: (str: string) => string;
/**
 * @hidden
 */
export declare const getFirstNumberIndex: (prevLooseValue: string, inputRegex: RegExp) => number;
/**
 * @hidden
 */
export declare const getDecimalCount: (value: string, decimal: string) => number;
/**
 * @hidden
 */
export declare const changeBasedSelection: (currentValue: string, nextValue: string, selectionPosition: number, isDelete: boolean, sanitizeRegex: any) => number;
/**
 * @hidden
 */
export declare const sanitizeNumber: (state: NumericTextBoxState, format: string | NumberFormatOptions, intlService: any) => NumericTextBoxState;
