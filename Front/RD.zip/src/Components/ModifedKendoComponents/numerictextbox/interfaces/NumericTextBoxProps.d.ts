import { FormComponentProps } from '@progress/kendo-react-common';
import { NumberFormatOptions } from '@progress/kendo-react-intl';
import { NumericTextBoxChangeEvent } from './NumericTextBoxChangeEvent';
import { NumericTextBoxFocusEvent } from './NumericTextBoxFocusEvent';
import { NumericTextBoxBlurEvent } from './NumericTextBoxBlurEvent';
declare type NumericTextBoxInputType = 'tel' | 'text';
/**
 * Represents the props of the [KendoReact NumericTextBox component]({% slug overview_numerictextbox %}).
 */
export interface NumericTextBoxProps extends FormComponentProps {
    /**
     * Sets a class of the NumericTextBox DOM element.
     */
    className?: string;
    /**
     * Specifies the value of the NumericTextBox.
     */
    value?: number | null;
    /**
     * Specifies the initial value. Leaves the subsequent updates uncontrolled.
     */
    defaultValue?: number | null;
    /**
     * Specifies the value that is used to increment or decrement the value of the NumericTextBox ([see example]({% slug predefinedsteps_numerictextbox %})).
     */
    step?: number;
    /**
     * Specifies the number format which is used for formatting the value ([see example]({% slug formats_numerictextbox %})). If set to `an empty string` or `undefined`, the default format will be used.
     */
    format?: string | NumberFormatOptions;
    /**
     * Specifies the width of the NumericTextBox.
     */
    width?: number | string;
    /**
     * Sets the `tabIndex` property of the NumericTextBox.
     */
    tabIndex?: number;
    /**
     * Specifies the `accessKey` of the NumericTextBox.
     */
    accessKey?: string;
    /**
     * Sets the title of the `input` element of the NumericTextBox.
     */
    title?: string;
    /**
     * Specifies the input placeholder.
     */
    placeholder?: string;
    /**
     * Specifies the smallest value that can be entered.
     */
    min?: number;
    /**
     * Specifies the greatest value that can be entered.
     */
    max?: number;
    /**
     * Specifies whether the **Up** and **Down** spin buttons will be rendered ([see example]({% slug spinbuttons_numerictextbox %})).
     */
    spinners?: boolean;
    /**
     * Determines whether the NumericTextBox is disabled.
     */
    disabled?: boolean;
    /**
     * Represents the `dir` HTML attribute.
     */
    dir?: string;
    /**
     * Specifies the name of the `input` DOM element.
     */
    name?: string;
    /**
     * Renders a floating label for the NumericTextBox.
     */
    label?: string;
    /**
     * Sets the `id` of the `input` DOM element.
     */
    id?: string;
    /**
     * Identifies the element(s) which will describe the component, similar to [HTML aria-describedby attribute](https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/ARIA_Techniques/Using_the_aria-describedby_attribute).
     * For example these elements could contain error or hint message.
     */
    ariaDescribedBy?: string;
    /**
     * Identifies the element(s) which will label the component.
     */
    ariaLabelledBy?: string;
    /**
     * Sets the `type` of the `input` DOM element.
     *
     * The available options are:
     * - (Default) `tel`
     * - `text`
     */
    inputType?: NumericTextBoxInputType;
    /**
     * If enabled, the NumericTextBox will handle the `enter` key to range the current invalid value between `min` and `max` props.
     * The available options are:
     * - (Default) `true`
     * - `false`
     * Can be disabled when form submit is required on pressing the `enter` key.
     */
    rangeOnEnter?: boolean;
    /**
     * Determines the event handler that will be fired when the user edits the value.
     */
    onChange?: (event: NumericTextBoxChangeEvent) => void;
    /**
     * The event handler that will be fired when NumericTextBox is focused.
     */
    onFocus?: (event: NumericTextBoxFocusEvent) => void;
    /**
     * The event handler that will be fired when NumericTextBox is blurred.
     */
    onBlur?: (event: NumericTextBoxBlurEvent) => void;
}
export {};
