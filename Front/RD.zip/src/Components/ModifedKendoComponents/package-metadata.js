/**
 * @hidden
 */
export var packageMetadata = {
    name: '@progress/kendo-react-inputs',
    productName: 'KendoReact',
    productCodes: ['KENDOUIREACT', 'KENDOUICOMPLETE'],
    publishDate: 1616067680,
    version: '',
    licensingDocsUrl: 'https://www.telerik.com/kendo-react-ui/my-license/?utm_medium=product&utm_source=kendoreact&utm_campaign=kendo-ui-react-purchase-license-keys-warning'
};
//# sourceMappingURL=package-metadata.js.map