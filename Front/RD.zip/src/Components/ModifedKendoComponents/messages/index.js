var _a;
/**
 * @hidden
 */
export var numericIncreaseValue = 'numerictextbox.increment';
/**
 * @hidden
 */
export var numericDecreaseValue = 'numerictextbox.decrement';
/**
 * @hidden
 */
export var sliderIncreaseValue = 'slider.increment';
/**
 * @hidden
 */
export var sliderDecreaseValue = 'slider.decrement';
/**
 * @hidden
 */
export var sliderDragTitle = 'slider.dragTitle';
/**
 * @hidden
 */
export var colorGradientR = 'colorGradient.r';
/**
 * @hidden
 */
export var colorGradientG = 'colorGradient.g';
/**
 * @hidden
 */
export var colorGradientB = 'colorGradient.b';
/**
 * @hidden
 */
export var colorGradientA = 'colorGradient.a';
/**
 * @hidden
 */
export var colorGradientHex = 'colorGradient.hex';
/**
 * @hidden
 */
export var checkboxValidation = 'checkbox.validation';
/**
 * @hidden
 */
export var checkboxOptionalText = 'checkbox.optionalText';
/**
 * @hidden
 */
export var radioButtonValidation = 'radioButton.validation';
/**
 * @hidden
 */
export var switchValidation = 'switch.validation';
/**
 * @hidden
 */
export var messages = (_a = {},
    _a[numericIncreaseValue] = 'Increase value',
    _a[numericDecreaseValue] = 'Decrease value',
    _a[sliderIncreaseValue] = 'Increase',
    _a[sliderDecreaseValue] = 'Decrease',
    _a[sliderDragTitle] = 'Drag',
    _a[colorGradientR] = 'r',
    _a[colorGradientG] = 'g',
    _a[colorGradientB] = 'b',
    _a[colorGradientA] = 'a',
    _a[colorGradientHex] = 'hex',
    _a[checkboxValidation] = 'Please check this box if you want to proceed!',
    _a[checkboxOptionalText] = '(Optional)',
    _a[radioButtonValidation] = 'Please select option if you want to proceed!',
    _a[switchValidation] = 'Please turn on if you want to proceed!',
    _a);
//# sourceMappingURL=index.js.map