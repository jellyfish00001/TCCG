/**
 * @hidden
 */
export declare const numericIncreaseValue = "numerictextbox.increment";
/**
 * @hidden
 */
export declare const numericDecreaseValue = "numerictextbox.decrement";
/**
 * @hidden
 */
export declare const sliderIncreaseValue = "slider.increment";
/**
 * @hidden
 */
export declare const sliderDecreaseValue = "slider.decrement";
/**
 * @hidden
 */
export declare const sliderDragTitle = "slider.dragTitle";
/**
 * @hidden
 */
export declare const colorGradientR = "colorGradient.r";
/**
 * @hidden
 */
export declare const colorGradientG = "colorGradient.g";
/**
 * @hidden
 */
export declare const colorGradientB = "colorGradient.b";
/**
 * @hidden
 */
export declare const colorGradientA = "colorGradient.a";
/**
 * @hidden
 */
export declare const colorGradientHex = "colorGradient.hex";
/**
 * @hidden
 */
export declare const checkboxValidation = "checkbox.validation";
/**
 * @hidden
 */
export declare const checkboxOptionalText = "checkbox.optionalText";
/**
 * @hidden
 */
export declare const radioButtonValidation = "radioButton.validation";
/**
 * @hidden
 */
export declare const switchValidation = "switch.validation";
/**
 * @hidden
 */
export declare const messages: {
    [numericIncreaseValue]: string;
    [numericDecreaseValue]: string;
    [sliderIncreaseValue]: string;
    [sliderDecreaseValue]: string;
    [sliderDragTitle]: string;
    [colorGradientR]: string;
    [colorGradientG]: string;
    [colorGradientB]: string;
    [colorGradientA]: string;
    [colorGradientHex]: string;
    [checkboxValidation]: string;
    [checkboxOptionalText]: string;
    [radioButtonValidation]: string;
    [switchValidation]: string;
};
