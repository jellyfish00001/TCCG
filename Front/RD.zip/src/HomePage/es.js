export default {
    "datepicker": {
        "toggleCalendar": "Alternar calendario"
    },
    "calendar": {
        "today": "Hoy"
    },
    "dateinput": {
        "increment": "Incrementar valor",
        "decrement": "Disminuir valor"
    },
    "datetimepicker": {
        "date": "Fecha",
        "time": "Hora",
        "cancel": "Cancelar",
        "set": "Conjunto"
    },
    "timepicker": {
        "set": "Conjunto",
        "cancel": "Cancelar",
        "now": "Ahora",
        "selectNow": "Seleccionar ahora",
        "toggleTimeSelector": "Selector de tiempo de alternancia",
        "toggleClock": "Reloj de palanca"
    },
    "daterangepicker": {
        "swapStartEnd": "Swap start and end values",
        "start": "Comienzo",
        "end": "Fin"
    }
}